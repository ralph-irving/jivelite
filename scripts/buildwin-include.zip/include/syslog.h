#ifndef SYSLOG_H
#define SYSLOG_H

#undef HAVE_SYSLOG

#endif
